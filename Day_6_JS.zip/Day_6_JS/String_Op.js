
document.write("String_Operators_Example");
document.write("<br/>");
document.write("<br/>");


let s1 = "Royal";
let s2 = "Banna";
let s3 = s1 + " " + s2;
document.write(s3);
