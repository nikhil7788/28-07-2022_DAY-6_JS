

var n1=50,n2="50";
document.write("<br/>Number-A : ",n1);
document.write("<br/>Number-B : '50'");
document.write("<br/>");

if(n1==n2){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}


if(n1===n2){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

document.write("<hr/>");

var n3=50,n4=50;
document.write("<br/>Number-C : ",n3);
document.write("<br/>Number-D : ",n4);
document.write("<br/>");

if(n3==n4){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}


if(n3===n4){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}