

var x = 500;
x += 55;

document.write("Assignment_Op._Example");
document.write("<br/>");
document.write("<br/>",x);